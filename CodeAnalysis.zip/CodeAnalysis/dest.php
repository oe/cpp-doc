<?php 
// var_dump($_FILES);
// exit();
$arr = array();
define("UPLOAD_ERR_EMPTY",5);
$error = array(
    UPLOAD_ERR_OK			=> "No errors.", 
    UPLOAD_ERR_INI_SIZE		=> "Larger than upload_max_filesize.",
    UPLOAD_ERR_FORM_SIZE	=> "Larger than form MAX_FILE_SIZE.",
    UPLOAD_ERR_PARTIAL		=> "Partial upload.",
    UPLOAD_ERR_NO_FILE		=> "No file.",
    UPLOAD_ERR_NO_TMP_DIR	=> "No temporary directory.",
    UPLOAD_ERR_CANT_WRITE	=> "Can't write to disk.",
    UPLOAD_ERR_EXTENSION	=> "File upload stopped by extension.",
    UPLOAD_ERR_EMPTY		=> "File is empty." // add this to avoid an offset
  );

$type = array('image/gif','image/png','image/jpeg','image/x-icon');
$arr['error'] = 1;
if (empty($_FILES['pic'])) {
	$arr['msg'] = 'No file has been uploaded';
}else{
	if(!$_FILES['pic']['error'] && $_FILES['pic']['size'] === 0){
	    $_FILES['pic']['error'] = 5;
	}
	if ($_FILES['pic']['error']) {
		$arr['msg'] = isset($error[$_FILES['pic']['error']]) ? $error[$_FILES['pic']['error']] : 'failed to uploaded file';
	} else {
		if (in_array($_FILES['pic']['type'],$type)) {
			if(is_uploaded_file($_FILES['pic']['tmp_name'])){
				 $filetype = pathinfo($_FILES['pic']['name'], PATHINFO_EXTENSION);
				 $imgbinary = @file_get_contents($_FILES['pic']['tmp_name']);
				 $arr['error'] = 0;
				 $arr['data'] = 'data:image/' . $filetype . ';base64,' . base64_encode($imgbinary);
			}else{
				$arr['msg'] = 'What do you wanna do';
			}
		}else{
			$arr['msg'] = 'Format not surpported';
		}
	}
}
// var_dump($arr);
?>
<script type="text/javascript">
    window.top.window.myupload(<?=json_encode($arr) ?>);
</script>
