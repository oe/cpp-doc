
// AnalysisDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Analysis.h"
#include "AnalysisDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAnalysisDlg dialog



CAnalysisDlg::CAnalysisDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CAnalysisDlg::IDD, pParent)
	, m_strPath(_T(""))
	, m_isFile(true)
	, m_ignoreCmnt(false)
	, m_openResult(true)
	, m_cppOnly(true)
	, m_autoStart(true)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CAnalysisDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDTPATH, m_strPath);
	DDX_Control(pDX, IDC_EDTPATH, m_ctrlPath);
}

BEGIN_MESSAGE_MAP(CAnalysisDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BTNBROWSER, &CAnalysisDlg::OnBnClickedBtnbrowser)
	ON_BN_CLICKED(IDC_BTNANALYSIS, &CAnalysisDlg::OnBnClickedBtnanalysis)
	ON_BN_CLICKED(IDC_RADFILE, &CAnalysisDlg::OnBnClickedRadfile)
	ON_BN_CLICKED(IDC_RADFOLDER, &CAnalysisDlg::OnBnClickedRadfolder)
	ON_BN_CLICKED(IDC_CKIGNORECMNT, &CAnalysisDlg::OnBnClickedCkignorecmnt)
	ON_BN_CLICKED(IDC_CKONLYCPP, &CAnalysisDlg::OnBnClickedCkonlycpp)
	ON_BN_CLICKED(IDC_CKOPENRESULT, &CAnalysisDlg::OnBnClickedCkopenresult)
	ON_BN_CLICKED(IDC_CKAUTOSTART, &CAnalysisDlg::OnBnClickedCkautostart)
END_MESSAGE_MAP()


// CAnalysisDlg message handlers

BOOL CAnalysisDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	((CButton*)GetDlgItem(IDC_RADFILE))->SetCheck(TRUE);
	((CButton*)GetDlgItem(IDC_CKOPENRESULT))->SetCheck(TRUE);
	((CButton*)GetDlgItem(IDC_CKONLYCPP))->SetCheck(TRUE);
	((CButton*)GetDlgItem(IDC_CKAUTOSTART))->SetCheck(TRUE);
	//CFont stFont;
	//stFont.CreateFont(16,0,0,0,FW_BOLD,TRUE,FALSE,0,ANSI_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH | FF_SWISS,_T("Microsoft YaHei"));
	//GetDlgItem(IDC_STCTITLE)->SetFont(&stFont);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CAnalysisDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CAnalysisDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CAnalysisDlg::OnBnClickedBtnbrowser()
{
	// TODO: Add your control notification handler code here
	if (m_isFile)
	{
		CFileDialog dlg(TRUE,NULL,NULL,OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT,_T("CPP sourse files(*.cpp;*.cc;*.hpp)|*.cpp;*.cc;*.hpp|All files(*.*)|*.*||"));
		dlg.m_ofn.lpstrTitle= _T("Please choose a code file");
		if (IDOK == dlg.DoModal())
		{
			m_strPath=dlg.GetPathName();
			m_ctrlPath.SetWindowText(m_strPath);
		}
	} 
	else
	{
		//MessageBox(_T("Demo"),_T("Open folder"),MB_OKCANCEL|MB_DEFBUTTON2|MB_ICONINFORMATION);
		TCHAR szPath[_MAX_PATH];
		BROWSEINFO bi;
		bi.hwndOwner=NULL;
		bi.pidlRoot=NULL;
		bi.lpszTitle=_T("Please choose a folder");
		bi.pszDisplayName=szPath;
		bi.ulFlags=BIF_RETURNONLYFSDIRS;
		bi.lpfn=NULL;
		bi.lParam=NULL;
		LPITEMIDLIST pItemIDList=SHBrowseForFolder(&bi);
		if (pItemIDList)
		{
			if (SHGetPathFromIDList(pItemIDList,szPath))
			{
				m_strPath=szPath;
			}
			else
			{
				m_strPath="";
			}
			m_ctrlPath.SetWindowText(m_strPath);
		}
	}
}


void CAnalysisDlg::OnBnClickedBtnanalysis()
{
	// TODO: Add your control notification handler code here
}


void CAnalysisDlg::OnBnClickedRadfile()
{
	// TODO: Add your control notification handler code here
	m_isFile = true;
	GetDlgItem(IDC_BTNBROWSER)->SetWindowText(_T("Browser file..."));
}


void CAnalysisDlg::OnBnClickedRadfolder()
{
	// TODO: Add your control notification handler code here
	m_isFile = false;
	GetDlgItem(IDC_BTNBROWSER)->SetWindowText(_T("Browser folder..."));
}


void CAnalysisDlg::OnBnClickedCkignorecmnt()
{
	// TODO: Add your control notification handler code here
	if (((CButton*)GetDlgItem(IDC_CKIGNORECMNT))->GetCheck())
	{
		m_ignoreCmnt = true;
	}
	else
	{
		m_ignoreCmnt = false;
	}
}


void CAnalysisDlg::OnBnClickedCkonlycpp()
{
	// TODO: Add your control notification handler code here
	if (((CButton*)GetDlgItem(IDC_CKONLYCPP))->GetCheck())
	{
		m_cppOnly = true;
	}
	else
	{
		m_cppOnly = false;
	}
}


void CAnalysisDlg::OnBnClickedCkopenresult()
{
	// TODO: Add your control notification handler code here
	if (((CButton*)GetDlgItem(IDC_CKOPENRESULT))->GetCheck())
	{
		m_openResult = true;
	}
	else
	{
		m_openResult = false;
	}
}


void CAnalysisDlg::OnBnClickedCkautostart()
{
	// TODO: Add your control notification handler code here
	if (((CButton*)GetDlgItem(IDC_CKAUTOSTART))->GetCheck())
	{
		m_autoStart = true;
	}
	else
	{
		m_autoStart = false;
	}
}
