
// AnalysisDlg.h : header file
//

#pragma once
#include "afxwin.h"


// CAnalysisDlg dialog
class CAnalysisDlg : public CDialogEx
{
// Construction
public:
	CAnalysisDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_ANALYSIS_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CString m_strPath;
protected:
	bool m_isFile;
	bool m_ignoreCmnt;
	bool m_openResult;
	CEdit m_ctrlPath;
	bool m_cppOnly;
public:
	afx_msg void OnBnClickedBtnbrowser();
	afx_msg void OnBnClickedBtnanalysis();
	afx_msg void OnBnClickedRadfile();
	afx_msg void OnBnClickedRadfolder();
	afx_msg void OnBnClickedCkignorecmnt();
	afx_msg void OnBnClickedCkonlycpp();
	afx_msg void OnBnClickedCkopenresult();
	afx_msg void OnBnClickedCkautostart();
protected:
	bool m_autoStart;
};
