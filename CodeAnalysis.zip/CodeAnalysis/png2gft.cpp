#include <stdio.h>
#include <windows.h>

#define HEAD_BM  0x4D42
#define HEAD_PNG 0x5089

#define HEAD_GFT1 0x4754
#define HEAD_GFT2 0x0046

bool isEndWith(char *path,char* ext)
{
	return !stricmp(path+strlen(path)-strlen(ext),ext);
}

void ChangeExt(char *path,char* ext)
{
	int i = strlen(path);
	int j = strlen(ext);
	for(;j>0;j--)
	{
		path[i--]=ext[j];
	}
}
int main(int argc,char *argv[])
{
	if(argc==1)
	{
		MessageBox(0,"请将要转换的图片拖动到本程序上。","提示",MB_OK + MB_ICONINFORMATION);
		return 0;
	}

	for(int index=1;index<argc;index++)
	{
		FILE *fp,*out;
		fp = fopen(argv[index],"rb");
		if(fp!=NULL)
		{
			if(isEndWith(argv[index],".gft"))
			{
				fseek( fp, 0, SEEK_END);
				long length = ftell(fp);
				fseek( fp, 0x10, SEEK_SET);
				int offset = fgetc(fp);
				fseek( fp, offset, SEEK_SET);

				switch(fgetwc(fp))
				{
					case HEAD_BM:
						ChangeExt(argv[index],".bmp");
						break;
					case HEAD_PNG:
						ChangeExt(argv[index],".png");
						break;
				}
				fseek( fp, offset, SEEK_SET);
				out = fopen(argv[index],"wb");
				while(ftell(fp)!=length)
				{
					fputc(fgetc(fp),out);
				}
				fclose(out);
			}
			else
			{
				fseek( fp, 0, SEEK_END);
				long length = ftell(fp);
				fseek( fp, 0, SEEK_SET);

				ChangeExt(argv[index],".gft");
				out = fopen(argv[index],"wb");
				fputwc(HEAD_GFT1,out);
				fputwc(HEAD_GFT2,out);
				for(int fill=0;fill<6;fill++)
				{
					fputwc(0,out);
				}
				fputwc(20,out);
				fputwc(0,out);
				while(ftell(fp)!=length)
				{
					fputc(fgetc(fp),out);
				}
				fclose(out);
			}
		}
		fclose(fp);
	}
	MessageBox(0,"恭喜你，全部图片转换完成。","提示",MB_OK + MB_ICONINFORMATION);
}