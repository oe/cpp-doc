<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>upload</title>
	<style type="text/css">
		.hidden{
			display: none;
		}
		pre{
			display: block;
			color: black;
			word-break:break-all;
			word-wrap: break-word;
		}
	</style>
</head>
<body>
	<form action="./dest.php" method="post" enctype="multipart/form-data" target="file_upload">
		<input type="file" name="pic" >
		<input type="submit" value="Upload">
	</form>
	<pre id="ans"></pre>
	<iframe name="file_upload" class="hidden"></iframe>
	<script type="text/javascript">
		function myupload (str) {
			if (str['error']) {
				document.getElementById('ans').innerHTML = str['msg'];
			} else{
				document.getElementById('ans').innerHTML = str['data'];
			}
		}
	</script>
</body>
</html>