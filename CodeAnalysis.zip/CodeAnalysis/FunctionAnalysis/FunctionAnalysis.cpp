// FunctionAnalysis.cpp : DLL �A�v���P�[�V�����p�ɃG�N�X�|�[�g�����֐����`���܂��B
//

#include "stdafx.h"
#include "FunctionAnalysis.h"
#include <algorithm>     
#include <functional>
#include <vector>
#include <ctime>
#include <iostream>


//trim string
inline std::string&  lTrim(std::string   &ss)     
{     
	std::string::iterator   p=std::find_if(ss.begin(),ss.end(),std::not1(std::ptr_fun(isspace)));     
	ss.erase(ss.begin(),p);
	return  ss;     
}     

inline  std::string&  rTrim(std::string   &ss)     
{     
	std::string::reverse_iterator  p=std::find_if(ss.rbegin(),ss.rend(),std::not1(std::ptr_fun(isspace)));     
	ss.erase(p.base(),ss.end());     
	return   ss;     
}     

inline   std::string&   trim(std::string   &st)     
{     
	lTrim(rTrim(st));     
	return   st;    
}  

std::vector<std::string> split(const std::string& s) {

	std::vector<std::string> ret;
	typedef std::string::size_type string_size;
	string_size i = 0;

	// invariant: we have processed characters [original value of i, i)
	while (i != s.size()) {

		// ignore leading blanks
		// invariant: chartacters in range [original i, current i) are all spaces
		while (i !=s.size() && isspace(s[i]))
			++i;

		// find end of next word
		string_size j = i;
		// invariant: none of the characters in rang [original j, current j) is a space
		while (j != s.size() && !isspace(s[j]))
			++j;

		// if we found some nonewithspace characters
		if (i != j) {
			// copy from s starting at i and taking j - i chars
			ret.push_back(s.substr(i, j - i));
			i = j;
		}
	}
	return ret;
}


CFunctionAnalysis::CFunctionAnalysis()
{
	codeFilePath.assign("");
	codeLines = 0;
	outCmntLines = 0;
	inCmntLines = 0;
	blankLines = 0;
	funLines = 0;
}

CFunctionAnalysis::CFunctionAnalysis(std::string& fp)
{
	codeFilePath.assign(fp);
	codeLines = 0;
	outCmntLines = 0;
	inCmntLines = 0;
	blankLines = 0;
	funLines = 0;
}

CFunctionAnalysis::CFunctionAnalysis(const char* fp)
{
	codeFilePath.assign(fp);
	codeLines = 0;
	outCmntLines = 0;
	inCmntLines = 0;
	blankLines = 0;
	funLines = 0;
}

CFunctionAnalysis::~CFunctionAnalysis()
{
	if (inFile.is_open())
	{
		inFile.close();
	}
	if (outFile.is_open())
	{
		outFile.close();
	}
	//codeFilePath.~basic_string();
}

void CFunctionAnalysis::SetInFilePath(std::string& fp)
{
	codeFilePath.assign(fp);
}

void CFunctionAnalysis::SetInFilePath(const char* fp)
{
	codeFilePath.assign(fp);
}

const int CFunctionAnalysis::OpenFile(std::string& fp)
{
	codeFilePath.assign(fp);
	if (codeFilePath.empty())
	{
		return 1;
	}
	if (inFile.is_open())
	{
		inFile.close();
	}
	inFile.open(codeFilePath,std::ios::in|std::ios::_Nocreate);
	if (inFile.fail())
	{
		inFile.clear();
		return 2;
	}
	if (outFile.is_open())
	{
		outFile.close();
	}
	std::string ansPath = codeFilePath + "_codeAnalysis.txt";
	outFile.open(ansPath,std::ios::out|std::ios::app);
	if (outFile.fail())
	{
		outFile.clear();
		return 2;
	}
	return 4;
}

const int CFunctionAnalysis::OpenFile(const char* fp)
{
	codeFilePath.assign(fp);
	if (codeFilePath.empty())
	{
		return 1;
	}
	if (inFile.is_open())
	{
		inFile.close();
	}
	inFile.open(codeFilePath,std::ios::in|std::ios::_Nocreate);
	if (inFile.fail())
	{
		inFile.clear();
		return 2;
	}
	if (outFile.is_open())
	{
		outFile.close();
	}
	std::string ansPath = codeFilePath + "_codeAnalysis.txt";
	outFile.open(ansPath,std::ios::out|std::ios::app);
	if (outFile.fail())
	{
		outFile.clear();
		return 2;
	}
	return 4;
}

void CFunctionAnalysis::RestVars()
{
	codeFilePath.assign(NULL);
	codeLines = 0;
	outCmntLines = 0;
	inCmntLines = 0;
	blankLines = 0;
	funLines = 0;
	if (inFile.is_open())
	{
		inFile.close();
	}
	if (outFile.is_open())
	{
		outFile.close();
	}
}

void CFunctionAnalysis::AnalysisCode(bool cuntCmntInFun)
{
	if (!inFile.is_open())
	{
		std::cout<<"File not open";
		return;
	}
	time_t timeNow = time(NULL);  
	tm* pTime = new tm;
	localtime_s(pTime,&timeNow);
	outFile<<"/*---------------ENJOY--------------------*/"<<std::endl;
	outFile<<"Analysis of file " + codeFilePath;
	outFile<<". Generated at "<<pTime->tm_year+1900<<'-'<<pTime->tm_mon+1<<'-'<<pTime->tm_mday<<' '<<pTime->tm_hour<<':'<<pTime->tm_min<<':'<<pTime->tm_sec<<std::endl;
	delete pTime;
	outFile.width(28);
	outFile<<"Return type/modifier";
	outFile.width(40);
	outFile<<"Function name";
	outFile.width(12);
	outFile<<"lines";
	outFile.width(40);
	outFile<<"Arguments"<<std::endl;
	outFile<<"------------------------------------------------------------------------------------------------------------------------------------"<<std::endl;
	int tmpInt = 0;
	std::string tmpStr;
	while (getline(inFile,tmpStr))
	{
		++codeLines;
		lTrim(tmpStr);
		if (tmpStr.empty())
		{
			++blankLines;
			continue;
		}
		if (0 == tmpStr.find("//"))
		{
			++outCmntLines;
			continue;
		}
		tmpInt = FindMutilineCmnt(tmpStr);
		if (0 == tmpInt)
		{
			break;
		}
		if (2 == tmpInt)
		{
			continue;
		}
		tmpInt = FindFunction(tmpStr,cuntCmntInFun);
		if (0 == tmpInt || 4 == tmpInt)
		{
			break;
		}
		if (2 == tmpInt)
		{
			continue;
		}
		//std::cout<<tmpStr<<std::endl;
	}
	outFile<<std::endl;
	outFile.width(22);
	outFile<<"Code Lines:";
	outFile.width(10);
	outFile<<codeLines<<std::endl;
	outFile.width(22);
	outFile<<"out comment lines:";
	outFile.width(10);
	outFile<<outCmntLines<<std::endl;
	outFile.width(22);
	outFile<<"in comment lines:";
	outFile.width(10);
	outFile<<inCmntLines<<std::endl;
	outFile.width(22);
	outFile<<"blank lines:";
	outFile.width(10);
	outFile<<blankLines<<std::endl;
	outFile<<std::endl<<std::endl;
	inFile.close();
	outFile.close();
}

const int CFunctionAnalysis::FindMutilineCmnt(std::string& tmp,bool isFun)
{
	if (0 != tmp.find_first_of("/*"))
	{
		return 1;
	}
	++outCmntLines;
	if (isFun)
	{
		++funLines;
	}
	if (-1 != tmp.find("*/"))
	{
		return 2;
	}
	while (getline(inFile,tmp))
	{
		++codeLines;
		if (isFun)
		{
			++funLines;
		}
		++outCmntLines;
		if (-1 == tmp.find("*/"))
		{
			continue;
		}
		else
		{
			return 2;
		}	
	}
	return 0;
}

//bool cuntCmnt for take comment as function lines
const int CFunctionAnalysis::FindFunction(std::string& tmpStr,bool cuntCmnt)
{
	int cmntPos = tmpStr.find("//");
	if (-1 != cmntPos)
	{
		++inCmntLines;
	}
	if (-1 != tmpStr.find("#"))
	{
		return 1;
	}
	int funArguBegPos = tmpStr.find("(");
	if (-1 == funArguBegPos)
	{
		return 1;
	}
	if (0 == funArguBegPos)
	{
		outFile<<"Error occurred in line " + codeLines<<std::endl;
		return 4;
	}
	std::string returnType;
	std::string funName;
	std::string funArgu;
	std::vector<std::string> fun = split(tmpStr.substr(0,funArguBegPos));
	int tmpInt = fun.size();
	switch (tmpInt)
	{
	case 0:
		outFile<<"Error occurred in line " + codeLines<<std::endl;
		return 4;
	default:
		for (int i = 0; i < tmpInt - 1 ; ++i)
		{
			returnType +=" " + fun.at(i);
		}
		funName = fun.at(tmpInt -1);
	}
	funLines = 1;
	int lBraceCunt = 0; // left brace
	int funArguEndPos = tmpStr.find(")");
	if ((funArguEndPos - funArguBegPos) > 1)
	{
		funArgu = tmpStr.substr(funArguBegPos+1,funArguEndPos - funArguBegPos - 1);
	}
	tmpInt = tmpStr.find("{");
	if (-1 != tmpInt)
	{
		if (-1 != cmntPos)
		{
			if (cmntPos > tmpInt)
			{
				++lBraceCunt;
			}
		}
		else
		{
			++lBraceCunt;
		}
	}
	while (getline(inFile,tmpStr))
	{
		++codeLines;
		lTrim(tmpStr);
		if (tmpStr.empty())
		{
			++blankLines;
			continue;
		}
		cmntPos = tmpStr.find("//");
		if (0 == cmntPos)
		{
			++outCmntLines;
			if (cuntCmnt)
			{
				++funLines;
			}
			continue;
		}
		tmpInt = FindMutilineCmnt(tmpStr,cuntCmnt);
		if (0 == tmpInt || 4 == tmpInt)
		{
			break;
		}
		if (2 == tmpInt)
		{
			continue;
		}
		++funLines;
		if (-1 != tmpStr.find("{"))
		{
			++lBraceCunt;
		}
		if (-1 != tmpStr.find("}"))
		{
			--lBraceCunt;
		}
		if (1 > lBraceCunt)
		{
			outFile.width(28);
			outFile<<returnType;
			outFile.width(40);
			outFile<<funName;
			outFile.width(12);
			outFile<<funLines;
			outFile.width(40);
			outFile<<funArgu<<std::endl;
			return 2;
		}
	}
	return 0;
}