
#pragma warning(disable:4251)

#ifdef FUNCTIONANALYSIS_EXPORTS
#define FUNCTIONANALYSIS_API __declspec(dllexport)
//template  class FUNCTIONANALYSIS_API string;
#else
#define FUNCTIONANALYSIS_API __declspec(dllimport)
#endif

#include <string>
#include <fstream>
//using namespace std;
//class __declspec(dllimport) VecWrapper : vector<Node *> {};   // C4251

//class __declspec(dllimport) string {};   // C4251
class FUNCTIONANALYSIS_API CFunctionAnalysis {
public:
	
public:
	CFunctionAnalysis(void);
	CFunctionAnalysis(std::string& fp);
	CFunctionAnalysis(const char* fp);
	~CFunctionAnalysis();
	void SetInFilePath(std::string& fp);
	void SetInFilePath(const char* fp);
	//1 for path null
	//2 for file not exist
	//4 open success
	const int OpenFile(std::string& fp);
	const int OpenFile(const char* fp = nullptr);
	//void CuntCodeLines();
	void AnalysisCode(bool cuntCmntInFun = true);
	void RestVars();
	//1 not found
	//2 for check over for this time
	//4 for syntax error
	//0 for eof
	const int FindMutilineCmnt(std::string& tmp,bool isFun = false);
	const int FindFunction(std::string& tmp,bool cuntCmnt = true);
protected:
	std::string codeFilePath;
	std::ifstream inFile;
	std::ofstream outFile;
	int codeLines;
	int outCmntLines;
	int inCmntLines;
	int blankLines;
	int funLines;
};

//assume for multi comment:
//a multi comment start from a new line
//after a end tag of multi comment,there is no code.



